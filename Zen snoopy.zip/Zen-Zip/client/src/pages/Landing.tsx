import { Button } from "@/components/ui/button";
import { ArrowRight, Leaf, Wind, Sun } from "lucide-react";
import { motion } from "framer-motion";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-[#FDFCF8] text-foreground flex flex-col">
      {/* Navbar */}
      <nav className="p-6 md:p-10 flex justify-between items-center max-w-7xl mx-auto w-full">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white">
            <Leaf size={16} />
          </div>
          <span className="text-xl font-serif font-bold tracking-tight">Zen</span>
        </div>
        <Button 
          variant="outline" 
          onClick={handleLogin}
          className="rounded-full px-6 border-primary/20 hover:bg-primary/5 hover:text-primary"
        >
          Sign In
        </Button>
      </nav>

      {/* Hero */}
      <main className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-4xl mx-auto mt-10 md:mt-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-6"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-secondary text-secondary-foreground text-sm font-medium tracking-wide">
            Find your balance
          </span>
          <h1 className="text-5xl md:text-7xl font-serif font-medium leading-[1.1] text-primary-foreground/90 mix-blend-multiply text-slate-800">
            Organize your life, <br />
            <span className="text-primary italic">calm your mind.</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            A simple, mindful workspace for your habits, tasks, and thoughts. 
            Designed to bring clarity to your daily routine without the noise.
          </p>
          
          <div className="pt-8">
            <Button 
              size="lg" 
              onClick={handleLogin}
              className="rounded-full px-8 py-6 text-lg bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300 group"
            >
              Get Started
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </motion.div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24 w-full">
          <FeatureCard 
            icon={<Wind className="w-6 h-6 text-blue-500" />}
            title="Mindful Tasks"
            description="Focus on what matters today. Let go of the clutter."
            delay={0.2}
          />
          <FeatureCard 
            icon={<Leaf className="w-6 h-6 text-green-500" />}
            title="Habit Growth"
            description="Build consistency gently. Watch your streaks grow."
            delay={0.4}
          />
          <FeatureCard 
            icon={<Sun className="w-6 h-6 text-orange-500" />}
            title="Daily Reflection"
            description="Journal your thoughts and track your mood patterns."
            delay={0.6}
          />
        </div>
      </main>

      <footer className="p-8 text-center text-sm text-muted-foreground mt-20">
        <p>© {new Date().getFullYear()} Zen App. Breathe easy.</p>
      </footer>
    </div>
  );
}

function FeatureCard({ icon, title, description, delay }: { icon: React.ReactNode, title: string, description: string, delay: number }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay }}
      className="p-6 rounded-2xl bg-white border border-slate-100 shadow-sm hover:shadow-md transition-shadow text-left"
    >
      <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-serif font-semibold mb-2">{title}</h3>
      <p className="text-muted-foreground leading-relaxed">{description}</p>
    </motion.div>
  );
}
